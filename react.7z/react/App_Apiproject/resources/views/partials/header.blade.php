<header id="menu">

<ul>
  <li><a href="/home"><p>Trang Chủ</p></a></li>
  <li><a href=""><p>Trang người dùng</p></a></li>
  <li><a href=""><p>Cài đặt</p></a></li>
  <li><a href="#"><p>Khuyến mãi</p></a></li>
  <li><a href="add"><p>Đơn hàng</p></a></li>
  <li><a></a></li>
<li><a href="/cart"><MdAddShoppingCart /><p>Giỏ hàng</p></a></li>
</ul>
</header>