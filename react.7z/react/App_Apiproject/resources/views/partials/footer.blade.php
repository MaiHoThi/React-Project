<footer>
    <h4>Coppy right MAI</h4>
</footer>